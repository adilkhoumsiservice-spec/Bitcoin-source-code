# Updated Settings

- The `-maxmempool` and `-dbcache` startup parameters are now capped on 32-bit systems to 500MB and
  1GiB respectively.
