Updated RPCs
------------

- The waitfornewblock now takes an optional `current_tip` argument. It is also no longer hidden. (#30635)
- The waitforblock and waitforblockheight RPCs are no longer hidden.  (#30635)
