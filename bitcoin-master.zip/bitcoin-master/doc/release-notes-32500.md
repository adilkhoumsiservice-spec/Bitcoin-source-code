### Updated Settings

- The `-upnp` setting has now been fully removed. Use `-natpmp` instead. (#32500)
