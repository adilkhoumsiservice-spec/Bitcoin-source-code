GUI changes

- Custom column widths in the Transactions tab are reset as a side-effect of legacy wallet removal. (#32459)
