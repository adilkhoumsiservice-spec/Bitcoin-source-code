# RPC

- The RPCs psbtbumpfee and bumpfee allow a replacement under fullrbf and no
  longer require BIP-125 signalling. (#31953)

# GUI

- A transaction's fee bump is allowed under fullrbf and no longer requires
  BIP-125 signalling. (#31953)
