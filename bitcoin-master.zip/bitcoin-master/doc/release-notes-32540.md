New RPCs
--------

- A new REST API endpoint (`/rest/spenttxouts/BLOCKHASH`) has been introduced for
  efficiently fetching spent transaction outputs using the block's undo data (#32540).
