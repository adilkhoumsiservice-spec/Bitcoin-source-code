See [doc/build-\*.md](/doc)
